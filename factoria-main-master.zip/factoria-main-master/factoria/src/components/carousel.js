// import React from 'react';
// import { Link } from 'react-router-dom';
// import '../css/carousel.css';
// import ej from '../img/400x400.png';
// import Carousel from 'react-bootstrap/Carousel'
// import imgC from '../img/sintitulo.jpg';


// // const Carousel = () => {
// //     return (

// //     );

// // }
// // export default Carousell;

// function Carousell() {
//     return (
//         <Carousel className>
//             <Carousel.Item>
//                 <img
//                     className="imgC d-block w-100"
//                     src={ej}
//                     alt="First slide"
//                 />
//                 <Carousel.Caption>
                    
//                 </Carousel.Caption>
//             </Carousel.Item>


//             <Carousel.Item>
//                 <img
//                     className="imgC d-block w-100"
//                     src={ej}
//                     alt="Second slide"
//                 />

//                 <Carousel.Caption>
                    
//                 </Carousel.Caption>
//             </Carousel.Item>


//             <Carousel.Item>
//                 <img
//                     className="imgC d-block w-100"
//                     src={ej}
//                     alt="Third slide"
//                 />
//                 <Carousel.Caption>
                    
//                 </Carousel.Caption>
//             </Carousel.Item>


//             <Carousel.Item>
//                 <img
//                     className="imgC d-block w-100"
//                     src={ej}
//                     alt="Fourt slide"
//                 />
//                 <Carousel.Caption>
                    
//                 </Carousel.Caption>
//             </Carousel.Item>
            
//         </Carousel>
//     );
// }

// export default Carousell;