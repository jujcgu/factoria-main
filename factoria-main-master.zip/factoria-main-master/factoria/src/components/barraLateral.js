import React from 'react';
import '../css/barraLateral.css';

const BarraLateral = () => {
    
    return(
        <div className="barraLarealComponent w-100"></div>
    );
}

export default BarraLateral;